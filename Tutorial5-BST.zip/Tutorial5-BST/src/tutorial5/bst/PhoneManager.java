package tutorial5.bst;


public class PhoneManager {
    public static void main(String[] args) {
        Phones P = new Phones();
        Menu menu = new Menu();
        menu.add("Add a new phone");
        menu.add("View phones based on codes");
        menu.add("View phones between 2 prices");
        menu.add("Quit");
        int userChoice;
        do {
            userChoice = menu.getUserChoice();
            switch (userChoice) {
                case 1: {
                    P.insert();
                    System.out.println();
                    break;
                }
                case 2: {
                    P.printCode();
                    System.out.println();
                    break;
                }
                case 3: {
                    P.printPrice();
                    System.out.println();
                    break;
                }
                default:
                    System.out.println("Application Exited");
            }
        }while(userChoice >= 1 && userChoice <= 3);
    }
}