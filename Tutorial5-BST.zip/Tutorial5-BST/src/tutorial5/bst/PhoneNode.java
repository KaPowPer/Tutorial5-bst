package tutorial5.bst;

public class PhoneNode implements Comparable {
    String code;
    int price;
    PhoneNode left, right;

    public PhoneNode(String code, int price) {
        this.code = code;
        this.price = price;
    }

    public String getCode() {
        return code;
    }

    public void setCode(String code) {
        this.code = code;
    }

    public int getPrice() {
        return price;
    }

    public void setPrice(int price) {
        this.price = price;
    }
    
    public int compareTo(Object o){
        return this.code.compareTo(((PhoneNode)o).code);
    }
}